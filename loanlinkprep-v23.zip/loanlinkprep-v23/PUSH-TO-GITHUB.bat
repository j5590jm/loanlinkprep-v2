@echo off
cd /d "%~dp0"
echo Pushing loanlinkprep-v23 branch to https://github.com/j5590jm/loanlinkprep-v2 ...
git push -u origin loanlinkprep-v23 --force
echo.
pause

