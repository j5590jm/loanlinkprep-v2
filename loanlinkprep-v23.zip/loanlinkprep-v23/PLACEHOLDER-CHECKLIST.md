# LoanLink Prep v23: Launch Checklist

Built 2026-11-15. This file is created by `tools/build_site.py`, so it always matches the site.
Fill values in `tools/site_config.json`, run `python tools/build_site.py`, then upload the **contents** of `public_html/`.

## 1. Placeholders still on the site (9)

| Placeholder | Page(s) | What to put there |
|---|---|---|
| `[STRIPE_LINK_CHECKUP]` | `/checkup/`, `/services/` | Stripe Payment Link for the $297 Checkup. Set the link's after-payment redirect to https://loanlinkprep.com/thanks-checkup/ |
| `[STRIPE_LINK_PLAYBOOK]` | `/shop/`, `/tax-playbook/` | Stripe Payment Link for the $19.99 playbook. Set its after-payment redirect to https://loanlinkprep.com/thanks-playbook/ |
| `[STRIPE_LINK_SEO_AUDIT_AND_ROADMAP]` | `/services/` | Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day. |
| `[STRIPE_LINK_LOCAL_SEO_FIX]` | `/services/` | Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day. |
| `[STRIPE_LINK_GOOGLE_ADS_SETUP]` | `/services/` | Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day. |
| `[STRIPE_LINK_GOOGLE_ADS_TUNE_UP]` | `/services/` | Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day. |
| `[STRIPE_LINK_CONTENT_PACK]` | `/services/` | Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day. |
| `[STRIPE_LINK_REVIEW_BOOSTER_SETUP]` | `/services/` | Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day. |
| `[STRIPE_LINK_LOAN_READINESS_REVIEW]` | `/any-economy/`, `/services/` | Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day. |

## 2. Items waiting for your OK (switches in `site_config.json` under `show`)

| Switch | Now | What it shows |
|---|---|---|
| `notary_services` | off | Notary group on the Services page (built, hidden, linked from nowhere) |
| `checkup_guarantee` | off | "If we don't find at least 5 fixes worth making, you get a full refund." |
| `checkup_upsell_credit` | off | "Your $297 counts toward the AI Visibility Fix if you book it within 30 days." |
| `use_scorecard_checklist` | ON | Checkup checklist drafted from your scorecard (instead of the placeholder) |
| `recession.use_launch_price` | off | Recession Defense Plan launch price ($147, first 10 customers) instead of $197 |

## 3. Please read and confirm (we drafted these)

- Service outcomes, included bullets and turnaround times on `/services/`. You gave names and prices; we wrote the rest. Edit them in `SERVICE_GROUPS` in `tools/build_site.py`.
- Short descriptions for the four Coming soon kits on `/shop/`.
- Checkup and Playbook FAQ answers (in `build_site.py`, `FAQ_CHECKUP` and `FAQ_PLAYBOOK`).
- Privacy page: intake details deleted 90 days after delivery (taken from your earlier Checkup page draft). The new Recession Defense Plan section on `/privacy/` uses the same 90 days for intake forms and reports. Only keep that sentence if you will really delete them on that schedule.
- Checkup checklist on `/checkup/`: drafted from your scorecard because the placeholder was never replaced. Replace it with your own wording in `checkup_checklist` in `site_config.json` any time.
- Recession Defense Plan: intake emails go to jeff@loanlinkprep.com. Edit the three text blocks in `tools/src/pages/recession-plan.html` and `thanks-recession.html` if you want different wording.
- Regions page text (`tools/regions/regions.csv`): the five regions and their local notes are drafts. List only regions you actually serve.
- Julius AI: a card appears on `/tools/` only after you paste your personal referral link in `optional_affiliates` in `site_config.json`. `partners.dub.co/programs/julius` is the public sign-up page, so it is skipped.

## 4. Cloudflare and Hostinger settings (important)

- **Do not upload** the `private/` or `tools/` folders. `private/` holds your Recession stress-test spreadsheet and delivery notes.
- **Cloudflare > Scrape Shield > Email Address Obfuscation: turn OFF.** It injects a script. Our security policy blocks scripts, so your email would show as "[email protected]".
- Leave **Rocket Loader**, **Cloudflare Web Analytics**, **Zaraz** and any Hostinger analytics or website-builder add-ons **off**. They add scripts or tracking.
- Cloudflare SSL mode: **Full (strict)**, plus **Always Use HTTPS** on.
- In each Stripe Payment Link, set the confirmation page redirect (Checkup to `/thanks-checkup/`, Playbook to `/thanks-playbook/`).

## 5. Compliance check (privacy rules, banned words, names, one H1, hidden pages)

No problems found.
