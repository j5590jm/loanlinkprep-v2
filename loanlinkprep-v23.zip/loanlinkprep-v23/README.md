# LoanLink Prep v23

Static site for Hostinger behind Cloudflare. No JavaScript, no trackers, no outside files.

## Folders

| Folder | What it is |
|---|---|
| `public_html/` | **The finished site. Upload the contents of this folder.** |
| `tools/` | Builder scripts and page text. **Do not upload.** |
| `private/` | Recession stress-test spreadsheet and delivery notes. **Do not upload.** |
| `PLACEHOLDER-CHECKLIST.md` | Every placeholder still on the site, the page it's on, and what to put there. |

## Everyday use

1. Fill in links and switches in `tools/site_config.json`.
2. `python tools/build_site.py` rebuilds the site and runs the compliance check. It ends with READY TO UPLOAD or NOT READY TO UPLOAD.
3. `python tools/make_region_pages.py` builds the region pages (optional) and rebuilds the main site in the same run.
4. Upload everything inside `public_html/` to Hostinger's `public_html`.

Editing text: page wording is in `tools/src/pages/*.html`. Services, FAQs and shop items are in `tools/build_site.py`.

## Recession Defense Plan price

`site_config.json` > `recession`. The $197 standard link shows by default. Set `use_launch_price` to `true` for the $147 launch link (first 10 customers), then set it back to `false`. Every page, the sitemap data, the llms.txt line and the region pages update from this one switch.

## Region pages

Edit `tools/regions/regions.csv` (regions), `keywords.csv` (services) and `template.html` (the master page).
Each region needs its own `local_note`, `detail` and `towns`, or the pages will look like duplicates and can hurt your rankings.
List only regions you really serve.
