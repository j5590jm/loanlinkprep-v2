# LoanLinkPrep Recession Defense Plan - Launch Kit

## What is in this kit
| File | Where it goes |
|---|---|
| `public_html/recession-plan/index.html` | Sales page -> `tools\src\pages\` (or straight into `public_html\recession-plan\`) |
| `public_html/thanks-recession/index.html` | Post-payment page (noindex) |
| `public_html/assets/css/recession.css` | `public_html\assets\css\` (also `tools\src\assets\css\`) |
| `public_html/downloads/Recession-Plan-Intake-Form.docx` | `public_html\downloads\` |
| `Recession-Stress-Test-Model.xlsx` | Keep private. Upload to Google Sheets or use in Excel. NOT on the website. |

## Step 1 - Fill the 4 placeholders (find and replace across both pages)
- `{{PRICE}}` - your price (suggestion: below your $297 checkup; e.g. 147 to 197)
- `{{STRIPE_LINK}}` - Stripe Payment Link URL
- `{{INTAKE_EMAIL}}` - the inbox that receives intake forms
- Replace the `TODO` header/footer comment with the header/footer block copied from your checkup page, so nav and styling match. (I did not have your checkup source, so pages link to `site.css` and add a small `recession.css`.)

## Step 2 - Stripe (10 min)
1. Stripe Dashboard -> Payment Links -> Create. Product: "Recession Defense Plan", one-time, your price.
2. After payment -> "Don't show confirmation page" -> redirect to `https://loanlinkprep.com/thanks-recession/`.
3. Collect customer email and business name (custom field). Turn on email receipts.
4. Do a test-mode purchase first (card 4242 4242 4242 4242), then switch to live and copy the live link.
5. Put the live link in both buy buttons (and `site_config.json` if your build uses it).

## Step 3 - Wire into the site (15 min)
- Nav: add `<a href="/recession-plan/">Recession Plan</a>`.
- `services` and `any-economy` pages: add a card/link: "Recession Defense Plan - know your runway before a downturn" -> `/recession-plan/`.
- `sitemap.xml` - add:
```xml
<url><loc>https://loanlinkprep.com/recession-plan/</loc></url>
```
- `robots.txt` - add (keeps thanks page out of search; your existing thanks pages may already be listed):
```
Disallow: /thanks-recession/
```
- `llms.txt` - add:
```
- Recession Defense Plan ($PRICE one-time): done-for-you recession stress test for small and medium businesses - cash runway, break-even, revenue-drop scenarios, debt pressure, 30-60-90 day plan. Delivered within 48 hours of intake. https://loanlinkprep.com/recession-plan/
```
- Run `python tools\build_site.py` and fix anything its audit flags, then upload `public_html` to Hostinger.
- Check `.htaccess` CSP: the pages use only self-hosted CSS and no inline scripts/styles except two small inline `style` attributes on the sales-page hero note. If your CSP blocks inline styles, delete those two `style="..."` attributes.

## Step 4 - Privacy page addition (required)
Add this section:
> **Recession Defense Plan.** If you buy a Recession Defense Plan, you send us business figures (such as revenue, costs, cash, and debt totals). We use them only to prepare your report. To help write the report we process these figures with AI writing tools, and a person reviews every report before delivery. We never ask for bank logins, passwords, full account numbers, or Social Security or tax ID numbers. We do not sell your data. We keep intake forms and reports for [__] days after delivery, then delete them on request or automatically. Contact [email] to request deletion.

Fill in the retention number honestly. Before you run any customer data through an AI tool, check that tool's current data-use settings (opt out of training on your data where offered).

## Step 5 - Delivery workflow (per order)
1. Stripe emails you the order. Customer emails the intake form.
2. Open `Recession-Stress-Test-Model.xlsx`, enter their numbers in yellow cells on **Inputs**. Adjust nothing else.
3. Confirm **Hand Check** still says PASS against Case A/B using a fresh copy of the file (do this once tonight; the check only applies to sample inputs).
4. Copy the Inputs metrics and Stress Test table into the AI prompt below. The AI writes words only; it never recalculates.
5. Read the draft against the spreadsheet. Fix any number that does not match.
6. Export to PDF, email within 48 hours, delete the intake form on schedule.

### AI report prompt (paste with the numbers)
```
You are writing a Recession Defense Plan for a small business owner. Use ONLY the figures provided below. Do not calculate, estimate, or invent any numbers. If a figure is missing, say it was not provided.

Business type and notes: [paste from intake]
Verified metrics: [paste Inputs key metrics]
Stress test results: [paste Stress Test table]

Write, in plain English at an 8th-grade reading level:
1. Summary (3-4 sentences): how long the business can last and the biggest risk.
2. Cash runway and break-even explained.
3. What the stress tests show (one short paragraph each: -10%, -20%, -30%, costs +10%, late payments).
4. Debt pressure.
5. Protect / Cut / Improve / Watch - 3 to 5 specific items each, tied to the numbers and the owner's stated worries.
6. 30-60-90 day action plan, 3-5 actions per period, in priority order.
Do not promise outcomes. End with: "This report is for educational planning only and is not legal, tax, accounting, or financial advice."
```

### Email to customer
> Subject: Your Recession Defense Plan is ready
> Hi [Name], your plan is attached. Start with the one-page summary and the 30-day actions. Treat the numbers as a snapshot based on the figures you gave us. If anything looks off, reply and we'll check it. This report is educational planning, not legal, tax, accounting, or financial advice. - LoanLink Prep

### Email if the intake form is incomplete
> Subject: One quick thing for your Recession Defense Plan
> Hi [Name], thanks for the form. To finish your plan we need: [missing items]. A rough estimate is fine. Your 48-hour clock restarts when we receive it.

## Step 6 - Launch checklist
- [ ] Placeholders replaced (search `{{` in both pages - nothing should remain)
- [ ] Stripe test purchase redirects to `/thanks-recession/`
- [ ] Live Stripe link on both buttons; one real $ purchase (refund yourself) works
- [ ] Intake form downloads from the thanks page; intake email receives mail
- [ ] Privacy page updated; copy says "48 hours", no "perfect/guaranteed/instant"
- [ ] Both stress-test Hand Check cases pass (A in the file as shipped; paste B and confirm)
- [ ] Mobile view checked on your phone
- [ ] `build_site.py` audit clean; sitemap/robots/llms updated; uploaded
- [ ] Calendar reminder: deliver every order within 48 hours

## Decisions only you can make
- Price, retention period for customer files, and the intake email address.
- Whether to cap orders per day at launch so 48-hour delivery stays realistic.
