#!/usr/bin/env python3
"""
LoanLink Prep v23 - static site builder.

What it does
  1. Reads page content from tools/src/pages/*.html
  2. Wraps every page in the same header, footer and <head> (SEO, Open Graph, favicon)
  3. Builds service cards, shop cards, free download cards and FAQs from the data below
  4. Swaps in any placeholder values you filled in tools/site_config.json
  5. Writes the finished site to public_html/ (upload the CONTENTS of that folder to Hostinger)
  6. Writes sitemap.xml, robots.txt, llms.txt, .htaccess, favicons and share images
  7. Runs a compliance check (privacy rules, banned words, no names, one H1, etc.)
  8. Writes PLACEHOLDER-CHECKLIST.md next to this project

Run it:   python tools/build_site.py

Never touched by this script: public_html/downloads/, public_html/dl/, public_html/regions/
"""

import hashlib
import html
import json
import re
import shutil
import sys
from datetime import date
from pathlib import Path
from urllib.parse import quote

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
SRC = TOOLS / "src"
OUT = ROOT / "public_html"
TODAY = date.today().isoformat()

CONFIG = json.loads((TOOLS / "site_config.json").read_text(encoding="utf-8"))
SITE = CONFIG.get("site_url", "https://loanlinkprep.com").rstrip("/")
SHOW = CONFIG.get("show", {})

EMAIL = "jeff@loanlinkprep.com"
PHONE = "219-209-3467"
PHONE_TEL = "+12192093467"
ADDRESS_LINES = ["5475 Broadway, Unit #A244", "Merrillville, IN 46410"]

# Folders this script owns inside public_html (safe to delete and rebuild).
GENERATED_DIRS = ["assets", "services", "checkup", "shop", "tax-playbook", "free-resources",
                  "any-economy", "tools", "about", "contact", "privacy", "recession-plan",
                  "thanks-checkup", "thanks-playbook", "thanks-recession"]
PROTECTED_DIRS = ["downloads", "dl", "regions"]

PLAYBOOK_PDF = "/dl/ytp-8b30ac6d/2026-Year-End-Tax-Playbook.pdf"

# Recession Defense Plan: standard price by default. Set recession.use_launch_price to true in
# site_config.json to show the launch price (first 10 customers) and use the launch Stripe link instead.
RD = CONFIG.get("recession", {})
RD_LAUNCH = bool(RD.get("use_launch_price"))
RD_PRICE = RD.get("launch_price", 147) if RD_LAUNCH else RD.get("standard_price", 197)
RD_LINK = (RD.get("launch_link") if RD_LAUNCH else RD.get("standard_link")) or "[STRIPE_LINK_RECESSION]"
RD_PRICE_NOTE = "one-time, launch price for the first 10 plans" if RD_LAUNCH else "one-time"


# --------------------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------------------
def esc(text):
    return html.escape(str(text), quote=True)


def money(n):
    return f"${n:,.0f}" if float(n).is_integer() else f"${n:,.2f}"


def mailto(subject, body=""):
    url = f"mailto:{EMAIL}?subject={quote(subject)}"
    if body:
        url += f"&body={quote(body)}"
    return esc(url)


def stripe_key(name):
    return "[STRIPE_LINK_" + re.sub(r"[^A-Z0-9]+", "_", name.upper()).strip("_") + "]"


ICONS = {
    "loan": '<path d="M3 10h18L12 4 3 10z"/><path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8"/><path d="M3 20h18"/>',
    "tax": '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/><path d="M10 17l5-6"/><circle cx="10.5" cy="11.5" r="1"/><circle cx="14.5" cy="16.5" r="1"/>',
    "ai": '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/><path d="M10 10h4v4h-4z"/>',
    "search": '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
    "book": '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5"/><path d="M8 7h7M8 11h7"/>',
    "download": '<path d="M12 4v11"/><path d="M7 10l5 5 5-5"/><path d="M4 20h16"/>',
}


def icon(name):
    return (f'<span class="icon-wrap"><svg class="icon" viewBox="0 0 24 24" width="30" height="30" fill="none" '
            f'stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" '
            f'aria-hidden="true" focusable="false">{ICONS[name]}</svg></span>')


LOGO_MARK = ('<svg viewBox="0 0 64 64" width="36" height="36" aria-hidden="true" focusable="false">'
             '<rect width="64" height="64" rx="14" fill="#0b1f36"/>'
             '<rect x="9" y="22" width="28" height="20" rx="10" fill="none" stroke="#d4a52f" stroke-width="5"/>'
             '<rect x="27" y="22" width="28" height="20" rx="10" fill="none" stroke="#f4e8c8" stroke-width="5"/>'
             '</svg>')


# --------------------------------------------------------------------------------------
# Services (one-time prices). Under $500 -> Stripe link. $500 and up -> "Request this" email.
# --------------------------------------------------------------------------------------
SERVICE_GROUPS = [
    {
        "token": "{{SERVICES_AI}}", "id": "ai-automation", "title": "AI and Automation",
        "intro": "Use AI safely in your firm, and make sure AI tools describe you correctly.",
        "services": [
            {"id": "checkup", "name": "AI + Search Visibility Checkup", "price": 297,
             "stripe": "[STRIPE_LINK_CHECKUP]", "detail": "/checkup/",
             "outcome": "See how search results, maps and AI assistants describe your firm, and what to fix first.",
             "includes": ["Scored visibility report", "Ranked fix list, most important first",
                          "Check of how AI assistants like ChatGPT answer questions about you",
                          "30-minute walkthrough call"],
             "turnaround": "5 business days"},
            {"id": "ai-policy-guardrails", "name": "AI Policy and Guardrails Package", "price": 750,
             "outcome": "Clear written rules for how your team uses AI with client information.",
             "includes": ["AI use policy written for your firm", "Approved and off-limits tools list",
                          "Client data and confidentiality rules", "Short staff training guide", "One review call"],
             "note": "We recommend your attorney review the final policy.",
             "turnaround": "7 business days"},
            {"id": "ai-receptionist", "name": "AI Receptionist Setup", "price": 997,
             "outcome": "Calls get answered, common questions handled and appointments booked, even after hours.",
             "includes": ["Help choosing a phone tool that fits your firm", "Greeting, FAQs and call routing set up",
                          "Appointment booking connected to your calendar", "Testing and a handoff walkthrough"],
             "note": "You pay the phone tool directly. We don't resell it or mark it up.",
             "turnaround": "10 business days"},
            {"id": "ai-visibility-fix", "name": "AI Visibility Fix", "price": 997,
             "outcome": "We make the fixes so search engines and AI assistants get your firm right.",
             "includes": ["Business listings and profile details corrected",
                          "Website titles, pages and business details cleaned up",
                          "Your services and service area made clear to AI assistants",
                          "Before-and-after summary"],
             "turnaround": "10 business days"},
            {"id": "automation-sprint", "name": "Automation Sprint", "price": 1500,
             "outcome": "One repetitive task handed off to software, set up and documented.",
             "includes": ["Pick one workflow, such as client intake, follow-ups or invoice reminders",
                          "Built and tested with tools you already use where possible",
                          "Written how-to for your team", "Follow-up check two weeks after launch"],
             "turnaround": "2 to 3 weeks"},
        ],
    },
    {
        "token": "{{SERVICES_SEO}}", "id": "seo-marketing", "title": "SEO and Marketing",
        "intro": "Get found by the clients already looking for what you do.",
        "services": [
            {"id": "seo-audit", "name": "SEO Audit and Roadmap", "price": 297,
             "outcome": "Find out why your site isn't showing up, with a plain-English plan to fix it.",
             "includes": ["Technical check: speed, mobile and indexing", "Page-by-page title and content review",
                          "Keyword gaps compared with local competitors", "Ranked 90-day roadmap"],
             "turnaround": "5 business days"},
            {"id": "local-seo-fix", "name": "Local SEO Fix", "price": 497,
             "outcome": "Show up correctly when people nearby search for what you do.",
             "includes": ["Business profile cleanup", "Name, address and phone made consistent across major directories",
                          "Category and service area review", "Local page recommendations"],
             "turnaround": "7 business days"},
            {"id": "google-ads-setup", "name": "Google Ads Setup", "price": 497,
             "outcome": "A clean, well-targeted first campaign that doesn't waste your budget.",
             "includes": ["Account and conversion setup", "Keyword research and negative keywords",
                          "Ad copy for one campaign", "Budget and bidding recommendations"],
             "note": "You pay ad spend directly to the ad platform.",
             "turnaround": "5 business days"},
            {"id": "google-ads-tune-up", "name": "Google Ads Tune-Up", "price": 297,
             "outcome": "Stop paying for clicks that never turn into clients.",
             "includes": ["Search terms reviewed and waste cut", "Negative keywords added",
                          "Ad and landing page suggestions", "Written summary of changes"],
             "turnaround": "5 business days"},
            {"id": "digital-marketing-launch", "name": "Digital Marketing Launch", "price": 1200,
             "outcome": "A simple, complete marketing foundation you can run yourself.",
             "includes": ["Clear messaging for your firm", "Copy edits for your key website pages",
                          "Business profile and directory setup", "90-day content and outreach plan", "Handoff call"],
             "turnaround": "3 weeks"},
            {"id": "content-pack", "name": "Content Pack", "price": 397,
             "outcome": "Ready-to-publish articles that answer your clients' real questions.",
             "includes": ["Topic plan based on what your clients search for", "Four articles written in your voice",
                          "Titles and meta descriptions", "One round of edits"],
             "turnaround": "10 business days"},
            {"id": "review-booster", "name": "Review Booster Setup", "price": 197,
             "outcome": "A simple, repeatable way to ask happy clients for reviews.",
             "includes": ["Review request templates for email and text", "Direct review link and QR code",
                          "When-to-ask guide for your team", "Reply templates for good and bad reviews"],
             "note": "Follows platform rules: no paid or filtered reviews.",
             "turnaround": "3 business days"},
        ],
    },
    {
        "token": "{{SERVICES_LOANS}}", "id": "loans-planning", "title": "Loans and Planning",
        "intro": "Walk into the bank prepared.",
        "services": [
            {"id": "loan-readiness-review", "name": "Loan-Readiness Review", "price": 297,
             "outcome": "Know where you stand before a lender looks at your file.",
             "includes": ["Review of your financial statements and tax returns", "Business credit and debt check",
                          "Document checklist for your loan type", "Gaps to fix, in order", "30-minute review call"],
             "note": "We're not a lender and we don't make credit decisions.",
             "turnaround": "5 business days"},
            {"id": "recession-defense-plan", "name": "Recession Defense Plan", "price": RD_PRICE,
             "price_note": RD_PRICE_NOTE, "stripe": RD_LINK, "detail": "/recession-plan/",
             "outcome": "Know how long your business can last if sales slow, and what to do first.",
             "includes": ["Cash runway and break-even point", "Stress tests if sales fall 10%, 20% or 30%",
                          "Cost increase and late-payment scenarios", "Debt pressure check",
                          "30-60-90 day action plan"],
             "note": "A planning report based on the figures you send us.",
             "turnaround": "48 hours after we receive your form"},
        ],
    },
    {
        # Hidden until confirmed: set show.notary_services to true in site_config.json.
        "token": "{{SERVICES_NOTARY}}", "id": "notary", "title": "Notary", "hidden_flag": "notary_services",
        "intro": "Documents notarized in person or online.",
        "services": [
            {"id": "notary-services", "name": "Notary Services", "price": 10, "price_note": "per signature",
             "request_only": True,
             "outcome": "Your documents notarized quickly and correctly.",
             "includes": ["Valid photo ID check", "Signer identity confirmed", "Notary journal entry"],
             "turnaround": "By appointment"},
            {"id": "mobile-notary", "name": "Mobile Notary", "price": 10, "price_note": "per signature, plus mileage",
             "request_only": True,
             "outcome": "We come to your office or home in Northwest Indiana.",
             "includes": ["Travel to your location", "Valid photo ID check", "Notary journal entry"],
             "turnaround": "By appointment"},
            {"id": "online-notary", "name": "Online Notary", "price": 25, "price_note": "per act",
             "request_only": True,
             "outcome": "Get documents notarized by secure video, from anywhere.",
             "includes": ["Secure video session", "Identity verification", "Electronic notary seal"],
             "turnaround": "By appointment"},
        ],
    },
]


def service_card(s):
    price = money(s["price"])
    name = s["name"]
    price_note = s.get("price_note", "one-time")
    items = "".join(f"<li>{esc(i)}</li>" for i in s["includes"])
    note = f'<p class="fine">{esc(s["note"])}</p>' if s.get("note") else ""
    if s["price"] < 500 and not s.get("request_only"):
        href = esc(s.get("stripe") or stripe_key(name))
        buttons = (f'<a class="btn btn-primary btn-block" href="{href}">Get started: {price}'
                   f'<span class="sr-only"> for the {esc(name)}</span></a>')
    else:
        body = (f"Hi, I'd like to request the {name}.\n\nBusiness name:\nWebsite:\n"
                f"Best phone number:\nWhat I'd like help with:\n")
        buttons = (f'<a class="btn btn-secondary btn-block" href="{mailto("Request: " + name, body)}">'
                   f'Request this<span class="sr-only">: {esc(name)}</span></a>')
    if s.get("detail"):
        buttons += (f'<a class="text-link" href="{s["detail"]}">See everything in the '
                    f'{esc(name)}</a>')
    return f"""
<article class="card card-accent" id="{s['id']}">
  <h3>{esc(name)}</h3>
  <div class="price-row"><span class="price">{price}</span><span class="price-note">{esc(price_note)}</span></div>
  <p class="outcome">{esc(s['outcome'])}</p>
  <ul class="checklist">{items}</ul>
  {note}
  <p class="meta-line"><strong>Turnaround:</strong> {esc(s['turnaround'])}</p>
  <div class="card-foot">{buttons}</div>
</article>"""


def service_group(g):
    if g.get("hidden_flag") and not SHOW.get(g["hidden_flag"]):
        return ""
    cards = "".join(service_card(s) for s in g["services"])
    return f"""
<section class="service-group" id="{g['id']}" aria-labelledby="{g['id']}-title">
  <div class="group-title"><h2 id="{g['id']}-title">{esc(g['title'])}</h2><p>{esc(g['intro'])}</p></div>
  <div class="grid">{cards}</div>
</section>"""


# --------------------------------------------------------------------------------------
# Shop
# --------------------------------------------------------------------------------------
PRODUCTS = [
    {"id": "tax-playbook", "name": "2026 Year-End Tax Playbook", "price": "$19.99", "available": True,
     "desc": "An 11-page PDF with a 6-week plan to capture 2026 tax savings before December 31.",
     "bullets": ["Instant download after payment", "No account and no email list",
                 "Written for owners of small service firms"],
     "detail": "/tax-playbook/", "stripe": "[STRIPE_LINK_PLAYBOOK]"},
    {"id": "crypto-tax-records-kit", "name": "Crypto Tax and Records Kit", "price": "$24.99", "available": False,
     "desc": "Templates to keep clean records of any crypto your firm holds or accepts, ready for tax time."},
    {"id": "ai-operations-kit", "name": "AI Operations Kit", "price": "$29", "available": False,
     "desc": "Prompts, checklists and policies to use AI in daily work, safely."},
    {"id": "bank-ready-loan-kit", "name": "Bank-Ready Loan Kit", "price": "$39", "available": False,
     "desc": "Checklists and templates to organize your financials before you talk to a lender."},
    {"id": "all-access-bundle", "name": "All-Access Bundle", "price": "$59", "available": False,
     "desc": "Every kit and playbook in the shop for one price."},
]


def product_card(p):
    if p["available"]:
        items = "".join(f"<li>{esc(b)}</li>" for b in p["bullets"])
        return f"""
<article class="card card-feature" id="{p['id']}">
  <span class="badge badge-green">Available now</span>
  <h2 class="h3-size">{esc(p['name'])}</h2>
  <div class="price-row"><span class="price">{p['price']}</span><span class="price-note">one-time</span></div>
  <p>{esc(p['desc'])}</p>
  <ul class="checklist">{items}</ul>
  <div class="card-foot">
    <a class="btn btn-primary btn-block" href="{p['stripe']}">Buy now: {p['price']}<span class="sr-only"> for the {esc(p['name'])}</span></a>
    <a class="text-link" href="{p['detail']}">See what's inside the {esc(p['name'])}</a>
  </div>
</article>"""
    return f"""
<article class="card" id="{p['id']}">
  <span class="badge badge-muted">Coming soon</span>
  <h2 class="h3-size">{esc(p['name'])}</h2>
  <div class="price-row"><span class="price">{p['price']}</span><span class="price-note">one-time</span></div>
  <p>{esc(p['desc'])}</p>
  <p class="meta-line card-foot"><strong>Not available yet.</strong></p>
</article>"""


# --------------------------------------------------------------------------------------
# Free resources (direct downloads, no email)
# --------------------------------------------------------------------------------------
FREEBIES = [
    {"file": "2026-Tax-Savings-Checklist.pdf", "title": "2026 Tax Savings Checklist", "type": "PDF",
     "benefit": "A quick checklist of tax moves to review before the year ends.",
     "next": ("Want the full 6-week plan? See the 2026 Year-End Tax Playbook", "/tax-playbook/")},
    {"file": "13-Week-Cash-Flow-Template.xlsx", "title": "13-Week Cash Flow Template", "type": "Excel",
     "benefit": "See the cash coming in and going out, week by week, for the next quarter.",
     "next": ("Getting ready to borrow? See the Bank-Ready Loan Kit (coming soon)", "/shop/#bank-ready-loan-kit")},
    {"file": "Employee-AI-Use-Policy-Template.docx", "title": "Employee AI Use Policy Template", "type": "Word",
     "benefit": "Set clear rules for how your team uses AI tools with client information.",
     "note": "Have an attorney review this template before you use it.",
     "next": ("Want a policy built for your firm? See the AI Policy and Guardrails Package",
              "/services/#ai-policy-guardrails")},
    {"file": "50-AI-Prompts-for-Business-Owners.pdf", "title": "50 AI Prompts for Business Owners", "type": "PDF",
     "benefit": "Ready-to-use prompts that save time on everyday business tasks.",
     "next": ("Curious what AI assistants say about your firm? See the AI + Search Visibility Checkup",
              "/checkup/")},
    {"file": "Downturn-Ready-Checklist.pdf", "title": "Downturn-Ready Checklist", "type": "PDF",
     "benefit": "Practical steps to protect your firm and prepare early for slower times.",
     "next": ("Read our guide to preparing for any economy", "/any-economy/")},
]


def file_size(rel):
    p = OUT / rel.lstrip("/")
    if not p.exists():
        return ""
    kb = max(1, round(p.stat().st_size / 1024))
    return f" &middot; {kb} KB"


def freebie_card(f, compact=False):
    href = f"/downloads/{f['file']}"
    note = f'<p class="fine"><strong>Note:</strong> {esc(f["note"])}</p>' if f.get("note") else ""
    nxt = "" if compact else f'<a class="text-link" href="{f["next"][1]}">{esc(f["next"][0])}</a>'
    return f"""
<article class="card">
  {icon('download')}
  <h3>{esc(f['title'])}</h3>
  <p>{esc(f['benefit'])}</p>
  <p class="meta-line"><strong>{f['type']} file</strong>{file_size(href)} &middot; Free, no email needed</p>
  {note}
  <div class="card-foot">
    <a class="btn btn-primary btn-block" href="{href}" download>Download<span class="sr-only"> the {esc(f['title'])}</span> ({f['type']})</a>
    {nxt}
  </div>
</article>"""


def freebie_by_file(name):
    return next(f for f in FREEBIES if f["file"] == name)


# --------------------------------------------------------------------------------------
# FAQs (rendered on the page AND as FAQPage structured data, so they always match)
# --------------------------------------------------------------------------------------
FAQ_CHECKUP = [
    ("Who is the Checkup for?",
     "Small firms that win business from local searches and referrals: accountants, insurance agents, "
     "attorneys, realtors, consultants, agencies and similar offices."),
    ("What exactly do I get?",
     "A scored report, a ranked list of fixes with the most important first, and a 30-minute call where we "
     "walk through it together. Everything is delivered within 5 business days of receiving your intake form."),
    ("Do you need my passwords?",
     "No. We never ask for passwords. We review what your customers can see. If you hire us later to make "
     "fixes, we'll ask you to give us limited access the safe way."),
    ("Can you promise top rankings or AI recommendations?",
     "No, and nobody honestly can. Search engines and AI assistants make their own choices. What we can do is "
     "show you what's holding you back and what to fix first."),
    ("Is this a subscription?",
     "No. You pay $297 once. There's no contract, no retainer and no monthly fee."),
    ("What happens after the call?",
     "You can make the fixes yourself or hand the list to your staff. If you'd rather we do the work, ask "
     "about the AI Visibility Fix."),
    ("How do I pay?",
     "Through Stripe, a secure payment processor. We never see or store your card number."),
]

FAQ_PLAYBOOK = [
    ("Who is the playbook for?",
     "Owners of small service firms, such as insurance agencies, law offices, real estate teams, consultants "
     "and agencies, who want to plan year-end moves before time runs out."),
    ("What format is it?",
     "An 11-page PDF. Read it on your phone or computer, or print it out."),
    ("How do I get it after I pay?",
     "Right after payment, Stripe sends you to a download page. Stripe also emails your receipt."),
    ("Do I need an account or have to join an email list?",
     "No. There's no account and no email list. Stripe collects your email only to send your receipt."),
    ("Is this tax advice?",
     "No. It's educational information to help you prepare. Bring the 15 questions inside to your CPA or tax "
     "preparer, who can advise on your situation."),
    ("What if I lose the file?",
     f"Email {EMAIL} with your receipt and we'll send it again."),
]


FAQ_RECESSION = [
    ("How long does the plan take?",
     "You receive your plan within 48 hours of us receiving your completed intake form."),
    ("Is this a subscription?",
     "No. It is a one-time payment. There is no contract, retainer or monthly fee."),
    ("Do you need my bank login?",
     "No. We never ask for bank logins, passwords or full account numbers. We only need monthly totals."),
    ("Is my information processed with AI?",
     "Yes. We use AI writing tools to help draft your report from the figures you send, and a person reviews "
     "every report before delivery. We never sell your data. See our privacy page for details."),
    ("Is this financial advice?",
     "No. It is an educational planning report based on the figures you provide. It does not guarantee any "
     "business outcome. Talk with a licensed professional about decisions specific to your situation."),
]


def faq_html(faqs):
    rows = "".join(f"<details><summary>{esc(q)}</summary><div><p>{esc(a)}</p></div></details>" for q, a in faqs)
    return f'<div class="faq">{rows}</div>'


def faq_schema(faqs):
    return {
        "@context": "https://schema.org", "@type": "FAQPage",
        "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}}
                       for q, a in faqs],
    }


PROFESSIONAL_SERVICE = {
    "@context": "https://schema.org", "@type": "ProfessionalService",
    "@id": f"{SITE}/#business",
    "name": "LoanLink Prep",
    "url": f"{SITE}/",
    "description": "One-time, pay-once help that makes small firms loan-ready, tax-ready and AI-ready, "
                   "plus SEO and digital marketing. No subscriptions.",
    "email": EMAIL,
    "telephone": "+1-219-209-3467",
    "foundingDate": "2025-05",
    "logo": f"{SITE}/assets/img/logo-512.png",
    "image": f"{SITE}/assets/img/og/home.png",
    "address": {"@type": "PostalAddress", "streetAddress": ADDRESS_LINES[0], "addressLocality": "Merrillville",
                "addressRegion": "IN", "postalCode": "46410", "addressCountry": "US"},
    "areaServed": [{"@type": "Place", "name": "Northwest Indiana"},
                   {"@type": "Country", "name": "United States"}],
}


# --------------------------------------------------------------------------------------
# Pages
# --------------------------------------------------------------------------------------
NAV = [("Services", "/services/"), ("Checkup", "/checkup/"), ("Shop", "/shop/"),
       ("Recession Plan", "/recession-plan/"),
       ("Free Resources", "/free-resources/"), ("Any Economy", "/any-economy/"),
       ("About", "/about/"), ("Contact", "/contact/")]

RECESSION_PRODUCT = {
    "@context": "https://schema.org", "@type": "Product",
    "name": "Recession Defense Plan",
    "description": "Done-for-you recession stress test for small and medium businesses: cash runway, "
                   "break-even, revenue-drop scenarios, debt pressure and a 30-60-90 day action plan.",
    "brand": {"@type": "Organization", "name": "LoanLink Prep", "url": f"{SITE}/"},
    "offers": {"@type": "Offer", "price": f"{RD_PRICE:.2f}", "priceCurrency": "USD",
               "url": f"{SITE}/recession-plan/", "availability": "https://schema.org/InStock"},
}

PAGES = [
    {"path": "/", "src": "home.html",
     "title": "LoanLink Prep | Loan, Tax and AI-Ready Help for Small Firms",
     "desc": "One-time help that makes small firms loan-ready, tax-ready and AI-ready. No subscriptions. "
             "No trackers. Pay once. Based in Merrillville, Indiana.",
     "og": "Loan-ready, tax-ready and AI-ready help for small firms.", "schema": [PROFESSIONAL_SERVICE]},
    {"path": "/services/", "src": "services.html",
     "title": "Services and One-Time Prices | LoanLink Prep",
     "desc": "AI, SEO, marketing and loan-readiness services for small firms. Every service has one fixed "
             "price. No retainers, contracts or monthly fees.",
     "og": "One-time services for small firms. No retainers."},
    {"path": "/checkup/", "src": "checkup.html",
     "title": "AI + Search Visibility Checkup, $297 One-Time | LoanLink Prep",
     "desc": "See how your firm shows up in search results, maps and AI assistants like ChatGPT. Scored "
             "report, ranked fix list and a 30-minute call in 5 business days.",
     "og": "AI + Search Visibility Checkup: $297, one-time.", "schema": [faq_schema(FAQ_CHECKUP)]},
    {"path": "/shop/", "src": "shop.html",
     "title": "Kits and Playbooks for Small Firms | LoanLink Prep",
     "desc": "Pay-once kits and playbooks for small firm owners. Instant download, no account and no "
             "email list.",
     "og": "Pay-once kits and playbooks for small firms."},
    {"path": "/tax-playbook/", "src": "tax-playbook.html",
     "title": "2026 Year-End Tax Playbook, $19.99 | LoanLink Prep",
     "desc": "Most tax savings expire on December 31. An 11-page PDF with a 6-week plan for small service "
             "firms. Pay once and download instantly.",
     "og": "Most tax savings expire on December 31.", "schema": [faq_schema(FAQ_PLAYBOOK)]},
    {"path": "/free-resources/", "src": "free-resources.html",
     "title": "Free Templates and Checklists, No Email Needed | LoanLink Prep",
     "desc": "Free 2026 tax checklist, 13-week cash flow template, AI use policy template and more. "
             "Direct downloads. No email required.",
     "og": "Free templates and checklists. No email required."},
    {"path": "/any-economy/", "src": "any-economy.html",
     "title": "Prepare Your Small Firm for Any Economy | LoanLink Prep",
     "desc": "Calm, practical steps to protect your firm and prepare early: cash runway, smart cost cuts, "
             "credit lines, client concentration and pricing.",
     "og": "Protect your firm and prepare early, in any economy."},
    {"path": "/tools/", "src": "tools.html",
     "title": "Tools We Use and Recommend | LoanLink Prep",
     "desc": "The bookkeeping, business credit and crypto tax tools we recommend to small firms. Affiliate "
             "links are clearly disclosed.",
     "og": "Tools we use and recommend for small firms."},
    {"path": "/about/", "src": "about.html",
     "title": "About LoanLink Prep | Pay-Once Help Since 2025",
     "desc": "Founded in 2025 in Northwest Indiana. Practical, pay-once help for small firms, built "
             "privacy-first with no trackers and no subscriptions.",
     "og": "Practical, pay-once help for small firms."},
    {"path": "/contact/", "src": "contact.html",
     "title": "Contact LoanLink Prep | Merrillville, Indiana",
     "desc": "Email or call LoanLink Prep. We reply within 1 business day. Serving Northwest Indiana and "
             "small firms nationwide.",
     "og": "Contact LoanLink Prep. We reply within 1 business day."},
    {"path": "/privacy/", "src": "privacy.html",
     "title": "Privacy Policy | LoanLink Prep",
     "desc": "What we collect, what we don't, and how to ask us to delete your information. No analytics, "
             "no ad trackers, no email required for free downloads.",
     "og": "Privacy policy: no analytics, no ad trackers."},
    {"path": "/recession-plan/", "src": "recession-plan.html",
     "title": "Recession Defense Plan for Small Businesses | LoanLink Prep",
     "desc": "Done-for-you recession stress test for small businesses: cash runway, break-even, "
             "revenue-drop scenarios and a 30-60-90 day plan. One-time payment, 48-hour delivery.",
     "og": "Know how long your business can last if sales slow.",
     "schema": [RECESSION_PRODUCT, faq_schema(FAQ_RECESSION)]},
    {"path": "/thanks-recession/", "src": "thanks-recession.html", "noindex": True,
     "title": "Thank You, Send Us Your Numbers | LoanLink Prep",
     "desc": "Next steps for your Recession Defense Plan.", "og": "Thank you."},
    {"path": "/thanks-checkup/", "src": "thanks-checkup.html", "noindex": True,
     "title": "Thank You, Your Checkup Is Booked | LoanLink Prep",
     "desc": "Next steps for your AI + Search Visibility Checkup.", "og": "Thank you."},
    {"path": "/thanks-playbook/", "src": "thanks-playbook.html", "noindex": True,
     "title": "Thank You, Download Your Playbook | LoanLink Prep",
     "desc": "Download your 2026 Year-End Tax Playbook.", "og": "Thank you."},
    {"path": "/404.html", "src": "404.html", "noindex": True,
     "title": "Page Not Found | LoanLink Prep",
     "desc": "We couldn't find that page.", "og": "Page not found."},
]


def og_name(page):
    p = page["path"].strip("/").replace(".html", "")
    return p or "home"


def nav_list(current):
    items = []
    for label, href in NAV:
        cur = ' aria-current="page"' if href == current else ""
        items.append(f'<li><a href="{href}"{cur}>{label}</a></li>')
    return "<ul>" + "".join(items) + "</ul>"


def layout(page, body, css_href):
    canonical = SITE + (page["path"] if page["path"] != "/404.html" else "/")
    robots = "noindex, nofollow" if page.get("noindex") else "index, follow"
    og_img = f"{SITE}/assets/img/og/{page.get('og_file') or og_name(page)}.png"
    schema = "".join(
        f'\n<script type="application/ld+json">{json.dumps(s, ensure_ascii=False, separators=(",", ":"))}</script>'
        for s in page.get("schema", []))
    canonical_tag = "" if page.get("noindex") else f'\n<link rel="canonical" href="{canonical}">'
    menu_icon = ('<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" '
                 'stroke-width="2" stroke-linecap="round" aria-hidden="true" focusable="false">'
                 '<path d="M4 7h16M4 12h16M4 17h16"/></svg>')
    year = date.today().year
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(page['title'])}</title>
<meta name="description" content="{esc(page['desc'])}">
<meta name="robots" content="{robots}">{canonical_tag}
<meta property="og:type" content="website">
<meta property="og:site_name" content="LoanLink Prep">
<meta property="og:title" content="{esc(page['title'])}">
<meta property="og:description" content="{esc(page['desc'])}">
<meta property="og:url" content="{canonical}">
<meta property="og:image" content="{og_img}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="{esc(page['og'])} LoanLink Prep">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#0b1f36">
<link rel="icon" href="/favicon.ico" sizes="32x32">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="stylesheet" href="{css_href}">{schema}
</head>
<body>
<a class="skip-link" href="#main">Skip to main content</a>
<header class="site-header">
  <div class="wrap header-inner">
    <a class="brand" href="/">{LOGO_MARK}<span class="brand-name">LoanLink <span>Prep</span></span></a>
    <nav class="nav-desktop" aria-label="Main">{nav_list(page['path'])}</nav>
    <details class="nav-mobile">
      <summary>{menu_icon}<span>Menu</span></summary>
      <nav aria-label="Main menu">{nav_list(page['path'])}</nav>
    </details>
  </div>
</header>
<main id="main">
{body}
</main>
<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div>
        <p class="footer-brand">LoanLink Prep &middot; Merrillville, Indiana &middot; Founded 2025</p>
        <span class="footer-label">Mailing address</span>
        <address>{ADDRESS_LINES[0]}<br>{ADDRESS_LINES[1]}</address>
      </div>
      <div>
        <span class="footer-label">Email and phone</span>
        <p><a href="mailto:{EMAIL}">{EMAIL}</a><br><a href="tel:{PHONE_TEL}">{PHONE}</a></p>
      </div>
      <nav aria-label="Footer">
        <span class="footer-label">Site</span>
        <ul>
          <li><a href="/services/">Services</a></li>
          <li><a href="/shop/">Shop</a></li>
          <li><a href="/free-resources/">Free Resources</a></li>
          <li><a href="/privacy/">Privacy</a></li>
          <li><a href="/tools/">Tools We Use</a></li>
        </ul>
      </nav>
    </div>
    <div class="footer-fine">
      <p>Some links are affiliate links.</p>
      <p>Educational information only. Not tax, legal or financial advice. LoanLink Prep is not a CPA firm, law firm or lender.</p>
      <p>&copy; {year} LoanLink Prep</p>
    </div>
  </div>
</footer>
</body>
</html>
"""


# --------------------------------------------------------------------------------------
# Tokens used inside tools/src/pages/*.html
# --------------------------------------------------------------------------------------
def checklist_html():
    items = CONFIG.get("checkup_checklist") or []
    if not items and SHOW.get("use_scorecard_checklist"):
        items = CONFIG.get("scorecard_checklist") or []
    if not items:
        return '<div class="placeholder-block"><p class="mb-0">[PASTE YOUR CHECKUP CHECKLIST HERE]</p></div>'
    return "".join(
        f'<div class="check-area"><h3>{esc(i["heading"])}</h3><p>{esc(i["text"])}</p></div>' for i in items)


def optional_affiliates_html():
    """Extra affiliate cards. A card only appears when a real personal referral link is set in
    site_config.json under optional_affiliates. Program sign-up pages are rejected on purpose, because
    a visitor who lands on a partner sign-up page earns you nothing."""
    cards = ""
    for a in CONFIG.get("optional_affiliates", []):
        link = (a.get("link") or "").strip()
        if not link:
            continue
        if "partners.dub.co/programs/" in link or "/apply" in link:
            print(f"  ! Skipped {a['name']}: that link is a partner sign-up page, not your personal referral link.")
            continue
        cards += (f'<article class="card"><h3>{esc(a["name"])}</h3><p>{esc(a["desc"])}</p>'
                  f'<div class="card-foot"><a class="btn btn-secondary btn-block aff" href="{esc(link)}" '
                  f'rel="sponsored nofollow noopener" target="_blank">Visit {esc(a["name"])}'
                  f'<span class="sr-only"> (opens in a new tab, affiliate link)</span></a></div></article>')
    if not cards:
        return ""
    return (f'<div class="group-title mt-lg"><h2>AI tools</h2></div><div class="grid">{cards}</div>')


def tokens():
    t = {
        "{{EMAIL}}": EMAIL,
        "{{EMAIL_LINK}}": f'<a href="mailto:{EMAIL}">{EMAIL}</a>',
        "{{PHONE}}": PHONE,
        "{{PHONE_LINK}}": f'<a href="tel:{PHONE_TEL}">{PHONE}</a>',
        "{{PHONE_TEL}}": PHONE_TEL,
        "{{ADDRESS_HTML}}": f"{ADDRESS_LINES[0]}<br>{ADDRESS_LINES[1]}",
        "{{PLAYBOOK_PDF}}": PLAYBOOK_PDF,
        "{{PLAYBOOK_SIZE}}": file_size(PLAYBOOK_PDF),
        "{{ICON_LOAN}}": icon("loan"), "{{ICON_TAX}}": icon("tax"), "{{ICON_AI}}": icon("ai"),
        "{{ICON_SEARCH}}": icon("search"), "{{ICON_BOOK}}": icon("book"), "{{ICON_DOWNLOAD}}": icon("download"),
        "{{FAQ_CHECKUP}}": faq_html(FAQ_CHECKUP),
        "{{FAQ_PLAYBOOK}}": faq_html(FAQ_PLAYBOOK),
        "{{CHECKUP_CHECKLIST}}": checklist_html(),
        "{{SHOP_CARDS}}": "".join(product_card(p) for p in PRODUCTS),
        "{{FREEBIE_CARDS}}": "".join(freebie_card(f) for f in FREEBIES),
        "{{FREEBIE_DOWNTURN}}": freebie_card(freebie_by_file("Downturn-Ready-Checklist.pdf"), compact=True),
        "{{FREEBIE_CASHFLOW}}": freebie_card(freebie_by_file("13-Week-Cash-Flow-Template.xlsx"), compact=True),
        "{{FREEBIE_TAXCHECK}}": freebie_card(freebie_by_file("2026-Tax-Savings-Checklist.pdf"), compact=True),
        "{{CHECKUP_GUARANTEE}}": "",
        "{{CHECKUP_UPSELL}}": "",
        "{{RD_PRICE}}": money(RD_PRICE),
        "{{RD_LINK}}": esc(RD_LINK),
        "{{RD_PRICE_NOTE}}": RD_PRICE_NOTE,
        "{{FAQ_RECESSION}}": faq_html(FAQ_RECESSION),
        "{{AFFILIATE_AI_TOOLS}}": optional_affiliates_html(),
        "{{AREAS_LINK}}": "",
        "{{LOAN_REVIEW_LINK}}": "[STRIPE_LINK_LOAN_READINESS_REVIEW]",
    }
    for g in SERVICE_GROUPS:
        t[g["token"]] = service_group(g)
    if SHOW.get("checkup_guarantee"):
        t["{{CHECKUP_GUARANTEE}}"] = (
            '<div class="notice"><p><strong>Our promise:</strong> If we don\'t find at least 5 fixes worth '
            'making, you get a full refund.</p></div>')
    if SHOW.get("checkup_upsell_credit"):
        t["{{CHECKUP_UPSELL}}"] = (
            '<p class="fine">Your $297 counts toward the <a href="/services/#ai-visibility-fix">AI Visibility '
            'Fix</a> if you book it within 30 days.</p>')
    if (OUT / "regions" / "index.html").exists():
        t["{{AREAS_LINK}}"] = ('<p>See the <a href="/regions/">regions we serve</a> in Northwest Indiana and '
                               'beyond.</p>')
    return t


def apply_placeholders(text):
    for key, value in CONFIG.get("placeholders", {}).items():
        if value:
            text = text.replace(key, esc(value))
    return text


# --------------------------------------------------------------------------------------
# Assets: CSS, favicons, share images
# --------------------------------------------------------------------------------------
FAVICON_SVG = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
               '<rect width="64" height="64" rx="14" fill="#0b1f36"/>'
               '<rect x="9" y="22" width="28" height="20" rx="10" fill="none" stroke="#d4a52f" stroke-width="5"/>'
               '<rect x="27" y="22" width="28" height="20" rx="10" fill="none" stroke="#f4e8c8" stroke-width="5"/>'
               '</svg>\n')


def font(names, size):
    from PIL import ImageFont
    for n in names:
        for base in (Path("C:/Windows/Fonts"), Path("/usr/share/fonts/truetype/dejavu"), Path("/Library/Fonts")):
            f = base / n
            if f.exists():
                return ImageFont.truetype(str(f), size)
    return ImageFont.load_default()


def draw_mark(size):
    from PIL import Image, ImageDraw
    s = size * 4
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    k = s / 64
    d.rounded_rectangle([0, 0, s - 1, s - 1], radius=int(14 * k), fill=(11, 31, 54, 255))
    w = max(1, int(5 * k))
    d.rounded_rectangle([9 * k, 22 * k, 37 * k, 42 * k], radius=int(10 * k), outline=(212, 165, 47, 255), width=w)
    d.rounded_rectangle([27 * k, 22 * k, 55 * k, 42 * k], radius=int(10 * k), outline=(244, 232, 200, 255), width=w)
    return img.resize((size, size), Image.LANCZOS)


def wrap_text(draw, text, fnt, max_w):
    words, lines, line = text.split(), [], ""
    for w in words:
        trial = (line + " " + w).strip()
        if draw.textlength(trial, font=fnt) <= max_w:
            line = trial
        else:
            lines.append(line)
            line = w
    if line:
        lines.append(line)
    return lines


def og_image(text, dest):
    from PIL import Image, ImageDraw
    W, H = 1200, 630
    img = Image.new("RGB", (W, H), (11, 31, 54))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 18, H], fill=(212, 165, 47))
    mark = draw_mark(72)
    img.paste(mark, (80, 64), mark)
    d.text((170, 80), "LoanLink Prep", font=font(["georgiab.ttf", "DejaVuSerif-Bold.ttf"], 44), fill=(255, 255, 255))
    size = 72
    while size > 40:
        f = font(["georgiab.ttf", "DejaVuSerif-Bold.ttf"], size)
        lines = wrap_text(d, text, f, W - 160)
        if len(lines) <= 3:
            break
        size -= 6
    y = 220 if len(lines) < 3 else 190
    for ln in lines:
        d.text((80, y), ln, font=f, fill=(255, 255, 255))
        y += int(size * 1.22)
    d.rectangle([80, H - 112, 200, H - 106], fill=(212, 165, 47))
    d.text((80, H - 92), "Pay once  \u00b7  No subscriptions  \u00b7  No trackers  \u00b7  Northwest Indiana",
           font=font(["segoeui.ttf", "DejaVuSans.ttf"], 30), fill=(195, 206, 219))
    img = img.quantize(colors=96, method=Image.Quantize.MEDIANCUT)
    img.save(dest, optimize=True)


def build_css_href():
    """Returns the versioned stylesheet URL without rebuilding anything (used by make_region_pages.py)."""
    css_src = SRC / "assets" / "css" / "site.css"
    return f"/assets/css/site.css?v={hashlib.sha256(css_src.read_bytes()).hexdigest()[:10]}"


def build_assets():
    css_src = SRC / "assets" / "css" / "site.css"
    css_out = OUT / "assets" / "css" / "site.css"
    css_out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(css_src, css_out)
    version = hashlib.sha256(css_src.read_bytes()).hexdigest()[:10]
    (OUT / "favicon.svg").write_text(FAVICON_SVG, encoding="utf-8")
    try:
        draw_mark(180).save(OUT / "apple-touch-icon.png", optimize=True)
        (OUT / "assets" / "img").mkdir(parents=True, exist_ok=True)
        draw_mark(512).save(OUT / "assets" / "img" / "logo-512.png", optimize=True)
        draw_mark(64).save(OUT / "favicon.ico", sizes=[(16, 16), (32, 32), (48, 48)])
        og_dir = OUT / "assets" / "img" / "og"
        og_dir.mkdir(parents=True, exist_ok=True)
        for page in PAGES:
            og_image(page["og"], og_dir / f"{og_name(page)}.png")
    except ImportError:
        print("  ! Pillow is not installed, so favicons and share images were skipped (pip install pillow).")
    return f"/assets/css/site.css?v={version}"


# --------------------------------------------------------------------------------------
# sitemap.xml, robots.txt, llms.txt, .htaccess
# --------------------------------------------------------------------------------------
def public_urls():
    urls = [p["path"] for p in PAGES if not p.get("noindex")]
    regions = OUT / "regions"
    if regions.exists():
        for idx in sorted(regions.rglob("index.html")):
            rel = "/" + idx.parent.relative_to(OUT).as_posix() + "/"
            urls.append(rel)
    return urls


def write_sitemap():
    rows = "".join(f"  <url><loc>{SITE}{u}</loc><lastmod>{TODAY}</lastmod></url>\n" for u in public_urls())
    (OUT / "sitemap.xml").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + rows + "</urlset>\n", encoding="utf-8")


def write_robots():
    (OUT / "robots.txt").write_text(
        "User-agent: *\n"
        "Disallow: /thanks-checkup/\n"
        "Disallow: /thanks-playbook/\n"
        "Disallow: /thanks-recession/\n"
        "Disallow: /dl/\n\n"
        f"Sitemap: {SITE}/sitemap.xml\n", encoding="utf-8")


def write_llms():
    lines = [
        "# LoanLink Prep", "",
        "> Loan-ready, tax-ready and AI-ready help for small firms. No subscriptions. No trackers. Pay once.", "",
        "LoanLink Prep was founded in May 2025 in Merrillville, Indiana. We serve Northwest Indiana and small "
        "firms nationwide online. We help white-collar small business owners such as accountants, insurance "
        "agents, attorneys, realtors, consultants and small agencies. Every offer is a one-time price: no "
        "subscriptions, retainers, contracts or monthly fees.", "",
        f"Contact: {EMAIL} | {PHONE} | Mailing address: {ADDRESS_LINES[0]}, {ADDRESS_LINES[1]}", "",
        "## Pages", "",
    ]
    for p in PAGES:
        if not p.get("noindex"):
            lines.append(f"- [{p['title'].split(' | ')[0]}]({SITE}{p['path']}): {p['desc']}")
    lines += ["", "## Services (one-time prices)", ""]
    for g in SERVICE_GROUPS:
        if g.get("hidden_flag") and not SHOW.get(g["hidden_flag"]):
            continue
        for s in g["services"]:
            lines.append(f"- {s['name']}: {money(s['price'])}. {s['outcome']} Turnaround: {s['turnaround']}.")
    lines += ["", "## Shop", ""]
    for p in PRODUCTS:
        status = "available now" if p["available"] else "coming soon"
        lines.append(f"- {p['name']}: {p['price']} ({status}). {p['desc']}")
    lines += ["", "## Free downloads (no email required)", ""]
    for f in FREEBIES:
        lines.append(f"- [{f['title']}]({SITE}/downloads/{f['file']}): {f['benefit']}")
    lines += ["", "Educational information only. Not tax, legal or financial advice. LoanLink Prep is not a "
                  "CPA firm, law firm or lender.", ""]
    (OUT / "llms.txt").write_text("\n".join(lines), encoding="utf-8")


HTACCESS = r"""# LoanLink Prep - Hostinger (Apache / LiteSpeed) settings
Options -Indexes
DirectoryIndex index.html
ErrorDocument 404 /404.html

<IfModule mod_headers.c>
  # Strict privacy and security headers. The site runs no JavaScript and loads nothing from other sites.
  Header always set Content-Security-Policy "default-src 'none'; style-src 'self'; img-src 'self'; font-src 'self'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'; upgrade-insecure-requests"
  Header always set X-Content-Type-Options "nosniff"
  Header always set Referrer-Policy "strict-origin-when-cross-origin"
  Header always set Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=(), usb=()"
  Header always set X-Frame-Options "DENY"

  # Keep thank-you pages and paid downloads out of search results.
  SetEnvIf Request_URI "^/(thanks-checkup|thanks-playbook|thanks-recession|dl)/" LLP_NOINDEX
  Header set X-Robots-Tag "noindex, nofollow" env=LLP_NOINDEX

  # Downloads save as files instead of opening in the browser.
  <FilesMatch "\.(docx|xlsx)$">
    Header set Content-Disposition "attachment"
  </FilesMatch>
</IfModule>

<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresDefault "access plus 1 hour"
  ExpiresByType text/html "access plus 0 seconds"
  ExpiresByType text/css "access plus 1 year"
  ExpiresByType image/png "access plus 1 month"
  ExpiresByType image/svg+xml "access plus 1 month"
  ExpiresByType image/x-icon "access plus 1 month"
</IfModule>

<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css text/plain text/xml application/xml image/svg+xml
</IfModule>

# Block hidden files (like .env or .git) if one is ever uploaded by mistake.
RedirectMatch 404 /\.(?!well-known/)
"""


# --------------------------------------------------------------------------------------
# Compliance check
# --------------------------------------------------------------------------------------
BANNED = [r"unfreezable", r"untraceable", r"sovereign", r"\bvaults?\b", r"hide assets",
          r"guaranteed approval", r"get rich"]
NAME_BLOCKLIST = [r"\bsarah\b", r"\bjeff\b(?!@loanlinkprep\.com)", r"\bfounder\b", r"\bowner'?s? name\b"]
ALLOWED_EXTERNAL = ("https://buy.stripe.com/", "https://koinly.io/", "https://changenow.app.link/")
PLACEHOLDER_RE = re.compile(r"\[[A-Z][A-Z0-9_ ]{2,}\]")


def audit(rendered):
    problems, notes = [], []
    titles, descs = {}, {}
    for path, text in rendered.items():
        visible = re.sub(r"<script[^>]*>.*?</script>", " ", text, flags=re.S)
        low = visible.lower()
        for pat in BANNED:
            if re.search(pat, low):
                problems.append(f"{path}: banned phrase matched /{pat}/")
        for pat in NAME_BLOCKLIST:
            if re.search(pat, low):
                problems.append(f"{path}: possible personal name or founder reference /{pat}/")
        if re.search(r"<script(?![^>]*application/ld\+json)", text):
            problems.append(f"{path}: contains a script tag (only JSON-LD data is allowed)")
        if re.search(r"<(iframe|embed|object|form)\b", text):
            problems.append(f"{path}: contains an iframe/embed/object/form")
        if re.search(r'\sstyle="', text):
            problems.append(f"{path}: inline style attribute (blocked by the CSP)")
        no_canonical = re.sub(r'<link rel="canonical"[^>]*>', "", text)
        for m in re.finditer(r'<(?:link|img|source|script)[^>]+(?:href|src)="(https?:)?//', no_canonical):
            problems.append(f"{path}: loads a file from another site: {m.group(0)[:80]}")
        h1s = len(re.findall(r"<h1[\s>]", text))
        if h1s != 1:
            problems.append(f"{path}: has {h1s} H1 headings (need exactly 1)")
        t = re.search(r"<title>(.*?)</title>", text).group(1)
        dsc = re.search(r'<meta name="description" content="(.*?)"', text).group(1)
        titles.setdefault(t, []).append(path)
        descs.setdefault(dsc, []).append(path)
        for m in re.finditer(r'<a\s[^>]*href="(https?://[^"]+)"[^>]*>', text):
            href, tag = m.group(1), m.group(0)
            if href.startswith(SITE):
                continue
            if not href.startswith(ALLOWED_EXTERNAL) and not any(
                    v and html.unescape(href) == v for v in CONFIG.get("placeholders", {}).values()):
                notes.append(f"{path}: external link to check: {href}")
        if path.startswith("/tools/"):
            for m in re.finditer(r'<a\s[^>]*class="[^"]*\baff\b[^"]*"[^>]*>', text):
                tag = m.group(0)
                if 'rel="sponsored nofollow noopener"' not in tag or 'target="_blank"' not in tag:
                    problems.append(f"{path}: affiliate link missing rel/target: {tag[:90]}")
    for t, paths in titles.items():
        if len(paths) > 1:
            problems.append(f"Duplicate title on {paths}")
    for d_, paths in descs.items():
        if len(paths) > 1:
            problems.append(f"Duplicate description on {paths}")
    checkup = rendered.get("/checkup/", "")
    t = re.search(r"<title>(.*?)</title>", checkup).group(1)
    h1 = re.search(r"<h1[^>]*>(.*?)</h1>", checkup, re.S).group(1)
    if "google" in (t + h1).lower():
        problems.append("/checkup/: the word Google appears in the product title or headline")
    for hidden in ("/thanks-checkup/", "/thanks-playbook/", "/thanks-recession/"):
        if 'content="noindex' not in rendered[hidden]:
            problems.append(f"{hidden}: missing noindex")
        for path, text in rendered.items():
            if path != hidden and f'href="{hidden}"' in text:
                problems.append(f"{path}: links to hidden page {hidden}")
    for path, text in rendered.items():
        if "notary" in text.lower() and not SHOW.get("notary_services"):
            problems.append(f"{path}: mentions notary while it is switched off")
    for f in FREEBIES:
        if not (OUT / "downloads" / f["file"]).exists():
            problems.append(f"Missing download file: public_html/downloads/{f['file']}")
    if not (OUT / PLAYBOOK_PDF.lstrip("/")).exists():
        problems.append(f"Missing paid playbook file: public_html{PLAYBOOK_PDF}")
    return problems, notes


PLACEHOLDER_HELP = {
    "[PASTE YOUR CHECKUP CHECKLIST HERE]": "Your checklist. Add it to checkup_checklist in tools/site_config.json, or set show.use_scorecard_checklist to true to use the version taken from your 3-Checkup-Scorecard.xlsx.",
    "[STRIPE_LINK_CHECKUP]": "Stripe Payment Link for the $297 Checkup. Set the link's after-payment redirect to https://loanlinkprep.com/thanks-checkup/",
    "[STRIPE_LINK_PLAYBOOK]": "Stripe Payment Link for the $19.99 playbook. Set its after-payment redirect to https://loanlinkprep.com/thanks-playbook/",
    "[INTAKE_FORM_LINK]": "Where buyers get the intake form. Easiest no-script option: /downloads/Checkup-Intake-Form.docx (already copied in). They fill it in and email it back.",
    "[QUICKBOOKS_CJ_TRACKING_LINK]": "Your CJ affiliate link for QuickBooks.",
    "[EXPERIAN_CJ_TRACKING_LINK]": "Your CJ affiliate link for Experian Business.",
    "[DATE]": "Privacy policy last-updated date, for example November 12, 2026.",
}


def write_placeholder_checklist(rendered, problems, notes):
    found = {}
    for path, text in rendered.items():
        for m in PLACEHOLDER_RE.findall(text):
            found.setdefault(m, set()).add(path)
    for extra in ("llms.txt",):
        pass
    order = list(CONFIG.get("placeholders", {}).keys())
    order.insert(0, "[PASTE YOUR CHECKUP CHECKLIST HERE]")
    keys = sorted(found, key=lambda k: order.index(k) if k in order else 99)
    rows = []
    for k in keys:
        pages = ", ".join(f"`{p}`" for p in sorted(found[k]))
        help_ = PLACEHOLDER_HELP.get(k, "Stripe Payment Link for this service (under $500). After-payment message: we'll email you within 1 business day.")
        rows.append(f"| `{k}` | {pages} | {help_} |")
    flags = [
        ("notary_services", "Notary group on the Services page (built, hidden, linked from nowhere)"),
        ("checkup_guarantee", "\"If we don't find at least 5 fixes worth making, you get a full refund.\""),
        ("checkup_upsell_credit", "\"Your $297 counts toward the AI Visibility Fix if you book it within 30 days.\""),
        ("use_scorecard_checklist", "Checkup checklist drafted from your scorecard (instead of the placeholder)"),
        ("recession.use_launch_price", "Recession Defense Plan launch price ($147, first 10 customers) instead of $197"),
    ]
    def flag_on(k):
        return bool(CONFIG.get(k.split(".")[0], {}).get(k.split(".")[1])) if "." in k else bool(SHOW.get(k))
    flag_rows = "\n".join(f"| `{k}` | {'ON' if flag_on(k) else 'off'} | {v} |" for k, v in flags)
    status = "No problems found." if not problems else "\n".join(f"- {p}" for p in problems)
    note_txt = "" if not notes else "\n\nLinks to double-check:\n" + "\n".join(f"- {n}" for n in notes)
    md = f"""# LoanLink Prep v23: Launch Checklist

Built {TODAY}. This file is created by `tools/build_site.py`, so it always matches the site.
Fill values in `tools/site_config.json`, run `python tools/build_site.py`, then upload the **contents** of `public_html/`.

## 1. Placeholders still on the site ({len(keys)})

| Placeholder | Page(s) | What to put there |
|---|---|---|
{chr(10).join(rows) if rows else '| none | | |'}

## 2. Items waiting for your OK (switches in `site_config.json` under `show`)

| Switch | Now | What it shows |
|---|---|---|
{flag_rows}

## 3. Please read and confirm (we drafted these)

- Service outcomes, included bullets and turnaround times on `/services/`. You gave names and prices; we wrote the rest. Edit them in `SERVICE_GROUPS` in `tools/build_site.py`.
- Short descriptions for the four Coming soon kits on `/shop/`.
- Checkup and Playbook FAQ answers (in `build_site.py`, `FAQ_CHECKUP` and `FAQ_PLAYBOOK`).
- Privacy page: intake details deleted 90 days after delivery (taken from your earlier Checkup page draft). The new Recession Defense Plan section on `/privacy/` uses the same 90 days for intake forms and reports. Only keep that sentence if you will really delete them on that schedule.
- Checkup checklist on `/checkup/`: drafted from your scorecard because the placeholder was never replaced. Replace it with your own wording in `checkup_checklist` in `site_config.json` any time.
- Recession Defense Plan: intake emails go to {EMAIL}. Edit the three text blocks in `tools/src/pages/recession-plan.html` and `thanks-recession.html` if you want different wording.
- Regions page text (`tools/regions/regions.csv`): the five regions and their local notes are drafts. List only regions you actually serve.
- Julius AI: a card appears on `/tools/` only after you paste your personal referral link in `optional_affiliates` in `site_config.json`. `partners.dub.co/programs/julius` is the public sign-up page, so it is skipped.

## 4. Cloudflare and Hostinger settings (important)

- **Do not upload** the `private/` or `tools/` folders. `private/` holds your Recession stress-test spreadsheet and delivery notes.
- **Cloudflare > Scrape Shield > Email Address Obfuscation: turn OFF.** It injects a script. Our security policy blocks scripts, so your email would show as "[email protected]".
- Leave **Rocket Loader**, **Cloudflare Web Analytics**, **Zaraz** and any Hostinger analytics or website-builder add-ons **off**. They add scripts or tracking.
- Cloudflare SSL mode: **Full (strict)**, plus **Always Use HTTPS** on.
- In each Stripe Payment Link, set the confirmation page redirect (Checkup to `/thanks-checkup/`, Playbook to `/thanks-playbook/`).

## 5. Compliance check (privacy rules, banned words, names, one H1, hidden pages)

{status}{note_txt}
"""
    (ROOT / "PLACEHOLDER-CHECKLIST.md").write_text(md, encoding="utf-8")
    return keys


# --------------------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------------------
def clean_output():
    OUT.mkdir(exist_ok=True)
    for d in GENERATED_DIRS:
        target = OUT / d
        if target.exists():
            shutil.rmtree(target)
    for f in ("index.html", "404.html", "sitemap.xml", "robots.txt", "llms.txt", ".htaccess",
              "favicon.svg", "favicon.ico", "apple-touch-icon.png"):
        (OUT / f).unlink(missing_ok=True)


def main():
    print(f"Building LoanLink Prep into {OUT}")
    clean_output()
    css_href = build_assets()
    toks = tokens()
    rendered = {}
    for page in PAGES:
        body = (SRC / "pages" / page["src"]).read_text(encoding="utf-8")
        for k, v in toks.items():
            body = body.replace(k, v)
        leftover = re.findall(r"\{\{[A-Z_]+\}\}", body)
        if leftover:
            print(f"  ! {page['src']}: unknown tokens {leftover}")
        text = apply_placeholders(layout(page, body, css_href))
        rendered[page["path"]] = text
        rel = page["path"].strip("/")
        if page["path"] == "/404.html":
            dest = OUT / "404.html"
        elif rel:
            dest = OUT / rel / "index.html"
        else:
            dest = OUT / "index.html"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(text, encoding="utf-8")
    write_sitemap()
    write_robots()
    write_llms()
    (OUT / ".htaccess").write_text(HTACCESS, encoding="utf-8")

    problems, notes = audit(rendered)
    keys = write_placeholder_checklist(rendered, problems, notes)
    print(f"  Pages written: {len(rendered)}")
    print(f"  Placeholders still to fill: {len(keys)} (see PLACEHOLDER-CHECKLIST.md)")
    if problems:
        print("  Compliance problems:")
        for p in problems:
            print("   -", p)
    else:
        print("  Compliance check: passed")
    for n in notes:
        print("  note:", n)
    if keys:
        print(f"\n  NOT READY TO UPLOAD: {len(keys)} placeholder(s) still show on the site:")
        for k in keys:
            print("   -", k)
    else:
        print("\n  READY TO UPLOAD: no placeholders left.")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
