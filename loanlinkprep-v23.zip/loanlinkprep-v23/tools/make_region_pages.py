#!/usr/bin/env python3
"""
LoanLink Prep - region page generator (the "copy-and-paste machine").

You give it:
  tools/regions/template.html   one master page design (the text between the header and footer)
  tools/regions/regions.csv     your list of regions (counties, metro areas, states)
  tools/regions/keywords.csv    your list of services / keywords

It writes one finished page for every region + keyword pair into public_html/regions/,
plus a /regions/ index page, then rebuilds the main site so the sitemap and links are up to date.
Then you upload public_html.

Run it (one command does everything):
    python tools/make_region_pages.py

Words you can use inside template.html (they get swapped for each page):
    {{REGION}} {{REGION_SHORT}} {{TOWNS}} {{LOCAL_NOTE}} {{DETAIL}}
    {{KEYWORD}} {{SERVICE}} {{PRICE}} {{LINK}} {{BLURB}}

IMPORTANT (read this, it protects your site):
  * Google penalizes large batches of near-identical pages ("doorway pages").
    Give each region its own local_note, detail and towns in regions.csv.
    This script warns about empty notes and very similar pages, and it stops at MAX_PAGES
    so you can't flood the site by accident.
  * Only list regions you actually serve. The template says you work online with firms there
    and that your mailing address is in Merrillville. Never claim an office you don't have.
  * In keywords.csv, a price of RD means "use the current Recession Defense Plan price from
    site_config.json", so the price on these pages always matches the sales page.
"""

import csv
import html
import re
import shutil
import sys
from difflib import SequenceMatcher
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import build_site as site  # reuses the same header, footer, SEO tags and rules  # noqa: E402

REGIONS_CSV = TOOLS / "regions" / "regions.csv"
KEYWORDS_CSV = TOOLS / "regions" / "keywords.csv"
TEMPLATE = TOOLS / "regions" / "template.html"
REGIONS = site.OUT / "regions"

MAX_PAGES = 150  # raise only if every page has real, different local content
SIMILARITY_WARNING = 0.92


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return [{k.strip(): (v or "").strip() for k, v in row.items()} for row in csv.DictReader(f)
                if any((v or "").strip() for v in row.values())]


def visible_text(page_html):
    body = re.search(r"<main.*?</main>", page_html, re.S)
    text = re.sub(r"<[^>]+>", " ", body.group(0) if body else page_html)
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def main():
    regions = read_csv(REGIONS_CSV)
    keywords = read_csv(KEYWORDS_CSV)
    template = TEMPLATE.read_text(encoding="utf-8")
    total = len(regions) * len(keywords)
    print(f"{len(regions)} regions x {len(keywords)} keywords = {total} pages")
    if total > MAX_PAGES:
        print(f"Stopping: {total} is more than MAX_PAGES ({MAX_PAGES}). Trim your lists or raise MAX_PAGES.")
        return 1

    # Start fresh each run so removed regions disappear.
    if REGIONS.exists():
        shutil.rmtree(REGIONS)
    REGIONS.mkdir(parents=True)

    css_href = site.build_css_href()
    made, problems, warnings, texts = [], [], [], {}

    for reg in regions:
        for field in ("local_note", "detail", "towns"):
            if not reg.get(field):
                warnings.append(f"{reg['region']}: {field} is empty. Add real local detail so pages differ.")
        for kw in keywords:
            slug = f"{kw['slug']}-{reg['slug']}"
            price = site.money(site.RD_PRICE) if kw["price"] == "RD" else kw["price"]
            values = {
                "{{REGION}}": reg["region"], "{{REGION_SHORT}}": reg.get("region_short", reg["region"]),
                "{{TOWNS}}": reg.get("towns", ""), "{{LOCAL_NOTE}}": reg.get("local_note", ""),
                "{{DETAIL}}": reg.get("detail", ""),
                "{{KEYWORD}}": kw["keyword"], "{{SERVICE}}": kw["service"], "{{PRICE}}": price,
                "{{LINK}}": kw["anchor"], "{{BLURB}}": kw["blurb"],
            }
            body = template
            for k, v in values.items():
                body = body.replace(k, html.escape(v, quote=False))
            left = re.findall(r"\{\{[A-Z_]+\}\}", body)
            if left:
                problems.append(f"{slug}: unknown template words {left}")

            short = reg.get("region_short", reg["region"])
            title = f"{kw['service']} in {short} | LoanLink Prep"
            if len(title) > 70:
                title = f"{kw['service']} in {short}"
            desc = (f"{kw['service']} for small firms in {reg['region']}. {price}, one-time. "
                    f"No subscriptions. Based in Merrillville, Indiana.")
            page = {"path": f"/regions/{slug}/", "title": title, "desc": desc,
                    "og": f"{kw['service']} in {short}", "og_file": "home"}
            full = site.apply_placeholders(site.layout(page, body, css_href))

            dest = REGIONS / slug / "index.html"
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(full, encoding="utf-8")
            made.append((slug, reg, kw))
            texts[slug] = visible_text(full)

            low = texts[slug].lower()
            for pat in site.BANNED + site.NAME_BLOCKLIST:
                if re.search(pat, low):
                    problems.append(f"{slug}: matched banned or name pattern /{pat}/")
            if len(re.findall(r"<h1[\s>]", full)) != 1:
                problems.append(f"{slug}: needs exactly one H1")
            if re.search(r"<script|<iframe|<form|\sstyle=\"", full):
                problems.append(f"{slug}: contains a script, iframe, form or inline style")

    # Index page listing every region page
    by_region = {}
    for slug, reg, kw in made:
        by_region.setdefault(reg["region_short"], []).append((slug, kw))
    sections = ""
    for label, items in by_region.items():
        links = "".join(f'<li><a href="/regions/{s}/">{html.escape(k["service"])} in {html.escape(label)}</a></li>'
                        for s, k in items)
        sections += f'<div class="card"><h2 class="h3-size">{html.escape(label)}</h2><ul>{links}</ul></div>'
    index_body = (
        '<section class="hero"><div class="wrap"><span class="kicker">Regions we serve</span>'
        '<h1>Regions we serve</h1><p class="lead">We are based in Merrillville, Indiana and work online with '
        'small firms across Northwest Indiana and nationwide. Pick your region to see how we can help.</p>'
        f'</div></section><section class="section"><div class="wrap"><div class="grid">{sections}</div></div></section>')
    index_page = {"path": "/regions/", "title": "Regions We Serve | LoanLink Prep",
                  "desc": "Small firms in Northwest Indiana and nationwide can work with LoanLink Prep online. "
                          "One-time prices, no subscriptions.",
                  "og": "Regions we serve", "og_file": "home"}
    (REGIONS / "index.html").write_text(site.layout(index_page, index_body, css_href), encoding="utf-8")

    # Too-similar check (compares each page with the next few)
    slugs = list(texts)
    flagged = 0
    for i in range(len(slugs)):
        for j in range(i + 1, min(i + 8, len(slugs))):
            if SequenceMatcher(None, texts[slugs[i]], texts[slugs[j]]).ratio() > SIMILARITY_WARNING:
                flagged += 1
                if flagged <= 5:
                    warnings.append(f"Very similar pages: {slugs[i]} and {slugs[j]}. Add more unique local detail.")

    print(f"Wrote {len(made)} region pages and the /regions/ index to {REGIONS}")
    for w in warnings:
        print("  warning:", w)
    for p in problems:
        print("  PROBLEM:", p)
    if problems:
        return 1
    print("Region pages: compliance check passed. Rebuilding the main site so links and sitemap are current...\n")
    return site.main()


if __name__ == "__main__":
    sys.exit(main())
